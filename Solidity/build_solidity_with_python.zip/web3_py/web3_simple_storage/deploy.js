import  fs from 'fs';
import Web3 from 'web3';
import  solc from 'solc';


const simpleStorageFile = fs.readFileSync('./SimpleStorage.sol', 'utf8');

console.log('Compiling...');
const input = {
    language: 'Solidity',
    sources: {
        'SimpleStorage.sol': {
            content: simpleStorageFile,
        },
    },
    settings: {
        outputSelection: {
            '*': {
                '*': ['abi', 'metadata', 'evm.bytecode', 'evm.bytecode.sourceMap'],
            },
        },
    },
};

const output = JSON.parse(solc.compile(JSON.stringify(input)));

const bytecode =
    output.contracts['SimpleStorage.sol']['SimpleStorage']['evm']['bytecode']['object'];

const abi = JSON.parse(
    output.contracts['SimpleStorage.sol']['SimpleStorage']['metadata']
).output.abi;

const web3 = new Web3('http://localhost:8545'); // Use the correct RPC URL

const myAddress = '0x6aABE487828603b6f0a3E1C7DAcF7F42bA42A9B2';
const privateKey =
    '8a63f5a3608d032ba652a323d62f333f71a895d253d6aa9f5defc16a43e4d7f1';

const deployContract = async () => {
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const gasPrice = await web3.eth.getGasPrice();

    const SimpleStorage = new web3.eth.Contract(abi);

    const deploy = SimpleStorage.deploy({
        data: bytecode,
    });

    const encodedTransaction = deploy.encodeABI();

    const tx = {
        nonce: nonce,
        gasPrice: gasPrice,
        data: encodedTransaction,
    };

    const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);

    console.log('Deploying Contract...');
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

    console.log(`Done! Contract deployed to ${receipt.contractAddress}`);
};

deployContract().then(async () => {
    const contractAddress = "contractAddress";
    const simpleStorage = new web3.eth.Contract(abi, contractAddress);

    console.log(`Initial Stored Value: ${ simpleStorage.methods.retrieve().call()}`);

    const nonce = await web3.eth.getTransactionCount(myAddress);
    const gasPrice = await web3.eth.getGasPrice();

    const setStoredValueTransaction = simpleStorage.methods.store();
    const encodedTransaction = setStoredValueTransaction.encodeABI();

    const tx = {
        nonce: nonce,
        gasPrice: gasPrice,
        data: encodedTransaction,
    };

    const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);

    console.log('Updating Stored Value...');
    const txHash = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

    const receipt = await web3.eth.getTransactionReceipt(txHash.transactionHash);
    console.log(receipt);

    console.log(`Stored Value Updated: ${await simpleStorage.methods.retrieve().call()}`);
});
